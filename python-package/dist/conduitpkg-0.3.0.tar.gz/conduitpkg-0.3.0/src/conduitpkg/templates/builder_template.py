# SPDX-FileCopyrightText: 2025-present Guille on a Raspberry pi <guilleleiratemes@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

template = """
# here is your builder, this works with zynk-lite

"""
# if you don't know zynk-lite don't worry i'm going to put a tutorial in the wiki of zynk-lite