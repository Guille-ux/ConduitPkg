# SPDX-FileCopyrightText: 2025-present Guille on a Raspberry pi <guilleleiratemes@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

template = { # there isn't builder_type because this runs the builder with zynk-lite
    "version":"0.0.1",
    "name":"",
    "author":"",
    "author_email":"",
    "mantainer_email":"",
    "license":"GPL-3.0-or-later",
    "dependencies":[],
    "entries":{},
}