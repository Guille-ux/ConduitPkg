# ConduitPkg

[![PyPI - Version](https://img.shields.io/pypi/v/conduitpkg.svg)](https://pypi.org/project/conduitpkg)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/conduitpkg.svg)](https://pypi.org/project/conduitpkg)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install conduitpkg
```

## License

`conduitpkg` is distributed under the terms of the [GPLv3 or later](https://spdx.org/licenses/GPL-3.0-or-later.html) license.
